#include "funciones.h"

int main()
{
	inicio();
	return 0;
}